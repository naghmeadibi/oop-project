public class Farmanimals {
   protected int price;
   protected int timeNeededToProduce;
}
