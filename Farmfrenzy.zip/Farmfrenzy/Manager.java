import java.util.LinkedList;

public class Manager {



    public int buyAnimal(int coin){
        int  newCoin = coin;
        return newCoin;
    }

    public void pickup(int coordinates){

    }

    public int well(){
        return 5;
    }

    public int plant(int wellWater){
        int newWellWater = wellWater;
        return newWellWater;
    }

    public void work(){

    }

    public void cage(int coordinates){

    }

    public void truckLoad(){

    }

    public void truckUnLoad(){

    }

    public void truckGo(){

    }

    public void turn(int timeCounter){

    }

    public void grassToBeEatenAndWildAnimalToEat(LinkedList grass,LinkedList farmAnimal,LinkedList wildAnimal){

    }

    public void moving(LinkedList animal,LinkedList tiger){

    }

    public int upgradeStore(int coin){
        int newCoin = coin;
        return coin;
    }
}
