public class Hen extends Farmanimals{

    public Hen() {
        this.price = 100;
        this.timeNeededToProduce = 2;
    }
}
