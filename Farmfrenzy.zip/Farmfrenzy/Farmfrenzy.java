public class Farmfrenzy {
    public static void main(String[] arg) {
        Egg e = new Egg();

    }
}
