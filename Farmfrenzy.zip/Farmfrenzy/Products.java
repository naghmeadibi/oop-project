public class Products {
    protected int live;
    protected int price;
    protected int capacity;
}
