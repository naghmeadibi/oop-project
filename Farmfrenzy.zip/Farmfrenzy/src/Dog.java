public class Dog {
    int coordinate;
    int price = 100;

    public Dog(int coordinate) {
        this.coordinate = coordinate;
    }
}
