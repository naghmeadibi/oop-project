public class Cat {
    int coordinate;
    int price = 150;

    public Cat(int coordinate) {
        this.coordinate = coordinate;
    }
}
