/**
 * Created by Atmospher-PC on 15/05/2021.
 */
public class Factory {
    protected int price;
    protected int time;
    protected Products inputProduct;
    protected Products outputProduct;

}
