import java.util.LinkedList;

public class Lion extends WildAnimals{

    public Lion(int coordinate) {
        this.coordinate = coordinate;
        this.life = 4;
        this.price=300;
        this.caged=-1;
    }
}
