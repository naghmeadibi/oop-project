import java.util.LinkedList;

public class Milk extends Products{

    public Milk(int coordinate) {
        this.price = 20;
        this.live = 4;
        this.capacity = 1;
        this.coordinate = coordinate;
        this.name = "milk";
    }

    public Milk(){

    }
}
