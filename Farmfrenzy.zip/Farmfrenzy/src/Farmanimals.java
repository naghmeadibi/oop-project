import java.util.LinkedList;

public class Farmanimals {
   protected int price;
   protected int timeNeededToProduce;
   protected int life = 10;
   protected int coordinate;


}
