import java.util.LinkedList;

public class Grass {

     int coordinate;

    public Grass(int coordinate) {
        this.coordinate = coordinate;
    }
}
