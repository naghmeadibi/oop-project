import java.util.LinkedList;

/**
 * Created by Atmospher-PC on 15/05/2021.
 */
public class Bakery extends Factory {

    Products products = new Products();
  //  Powder powder = new Powder();
  //  Bread bread = new Bread();
    public Bakery() {
        this.price = 250;
        this.time = 5;
    }
}
