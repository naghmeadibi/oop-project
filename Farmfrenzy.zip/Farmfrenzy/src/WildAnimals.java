import java.util.LinkedList;

public class WildAnimals {
    int life;
    int coordinate;
    int price;
    int caged;
    //اگه -1 ینی خارج قفس از پنج به پایین تعداد مرحله هایی که تو قفس بوده
}
