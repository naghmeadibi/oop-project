import java.util.LinkedList;

public class Egg extends Products {

    public Egg(int coordinate) {
        this.price = 15;
        this.live = 4;
        this.capacity = 1;
        this.coordinate = coordinate;
        this.name = "Egg";
    }
    public Egg() {

    }
}

