public class Turkey extends Farmanimals{
}
